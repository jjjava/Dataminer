package dataminer;

import java.io.File;

public class Dataminer {
  
    public static void main(String[] args) {
        core.Miner.listPath(new File("T:"));
    }
}